---Project Name :- STAPH

#### Recruitment Platform
-- A comprehensive job portal where employers can post jobs, manage applications, and send automated emails. Candidates can create profiles, upload resumes, apply for jobs, and track their applications. Admins have full control over job postings and user management.

#### Admin Features
- Login
- Manage Jobs, Manage Users

#### Candidate Features
- Register
- Login
- Create Profile
- Apply Jobs
- Track Job Applications

#### Employee Features
- Register
- Login
- Manage Job Posts
- Manage Job Applications
- Send Automated Email

##### Technoglogies Used
- PHP
- MySQL
- JavaScript
- EmailJS
- HTML/CSS


