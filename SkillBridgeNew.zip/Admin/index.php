<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin-Login</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../Job-Seeker/CSS/style.css">
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico">

</head>
<body>
    <!--Navbar-->
    <section>
        <nav class="navbar navbar-dark navbar-expand-lg bg-dark p-3 shadow">
            <div class="container">
                <a href="" class="navbar-brand">SkillBridge</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasDarkNavbar" aria-controls="offcanvasDarkNavbar">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="offcanvas offcanvas-top text-bg-dark" tabindex="-1" id="offcanvasDarkNavbar" aria-labelledby="offcanvasDarkNavbarLabel">
                    <div class="offcanvas-header">
                            <h5 class="offcanvas-title" id="offcanvasDarkNavbarLabel">SkillBridge</h5>
                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                    </div>
                </div>
            </div>
        </nav>
    </section>
    <main>
        <!--Register Form-->
        <section>
            <div class="container mt-5 shadow p-5">
                <div class="row justify-content-center">
                    <div class="col-12 col-sm-10 col-md-9 col-lg-8 col-xl-7 col-xxl-6">
                        <form action="PHP/admin-login.php" class="form" method="post">
                            <header>
                                <h4 class="text-center mb-3">Welcome Back</h4>
                            </header>
                            <?php
                            if(isset($_GET['login-fail'])){
                                echo("<div class='alert alert-danger mt-3' role='alert' id='login-failed'>
                                Invalid Credentials! Please try again
                                </div>");
                            }
                            ?>
                            <!--Server side Repsonse--->
                            <div class="alert alert-success" id="alert">
                                <strong>Response Type !</strong> Message
                            </div>
                            <!----->
                            <div class="row">
                                <div class="col-12 mb-3">
                                    <label for="email" class="form-label">Email</label>
                                    <input type="text" class="form-control" id="email" name="email">
                                    <h6 class="error-message" id="email-error"></h6>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-12 mb-3">
                                    <label for="password" class="form-label">Password</label>
                                    <input type="password" class="form-control" id="password" name="password">
                                    <h6 class="error-message" id="password-error"></h6>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-12">
                                    <button class="btn btn-primary w-100" type="submit" name="login">Login</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </main> 
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>