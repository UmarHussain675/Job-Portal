<?php

session_start();

if(isset($_POST['login'])){ // if login button is pressed

   $email = $_POST['email'];
   $pass = $_POST['password'];

   if($email == 'admin@skillbridge.com' && $pass == 'admin123'){
    $_SESSION['admin_id'] = $email;
    header('location:../profile/Admin-Dashboard.html'); 
   }else{
    header('location:../index.php?login-fail'); // error mesage
   }};

?>